<?php

$route = [];
// $route['default_controller'] = 'Home'; // dimatikan pada P6 karena penulisan index.php dihilangkan pada URL aplikasi
$route['default_controller'] = 'Katalog_controller'; // karena penulisan index.php dihilangkan pada URL aplikasi 
// $route['info/(:any)'] = 'home/info/$1';
// $route['default_controller'] = 'home';
// $route['info/(:any)'] = 'home/info/$1';
// Route autentikasi P3
$route['login'] = 'auth/login';
$route['auth/login'] = 'auth/login';
$route['auth/logout'] = 'auth/logout';

// Route halaman administrasi
$route['admin'] = 'admin/index';
// P4: BARU - semua proses CRUD admin dipindahkan di bawah /admin/madmin. 
$route['admin/madmin'] = 'madmin_controller/index';
$route['admin/madmin/tambah'] = 'madmin_controller/tambah';
$route['admin/madmin/ubah/(:any)'] = 'madmin_controller/ubah/$1';
$route['admin/madmin/hapus/(:any)'] = 'madmin_controller/hapus/$1';

// Route P5 
// dari href(menu), diproses ke Mobil_controller dengan mengerjakan method index() yang memanggil admin\mobil_view 
$route['admin/mobil'] = 'Mobil_controller/index';
$route['admin/mobil/tambah'] = 'Mobil_controller/tambah';
$route['admin/mobil/ubah/(:any)'] = 'Mobil_controller/ubah/$1';
$route['admin/mobil/hapus/(:any)'] = 'Mobil_controller/hapus/$1';

// Route P6 
$route['katalog'] = 'Katalog_controller/index';
$route['katalog/detail/(:any)'] = 'Katalog_controller/detail/$1';
$route['auth/login-penyewa'] = 'Auth/loginPenyewa';
$route['auth/logout-penyewa'] = 'Auth/logoutPenyewa';
$route['penyewa/profil'] = 'Penyewa_controller/profil';

// Route P7 - Transaksi, Keranjang, dan Checkout 
$route['transaksi/tambah'] = 'Transaksi_controller/tambah'; 
$route['transaksi/keranjang'] = 'Transaksi_controller/keranjang'; 
$route['transaksi/perbarui-periode'] = 'Transaksi_controller/perbaruiPeriode'; 
$route['transaksi/hapus'] = 'Transaksi_controller/hapus'; 
$route['transaksi/hapus/(:any)'] = 'Transaksi_controller/hapus/$1'; 
$route['transaksi/checkout'] = 'Transaksi_controller/checkout'; 

$route['admin/mobil'] = 'Mobil_controller/index';
$route['admin/penyewa'] = 'Manajemen_penyewa_controller/index';
$route['admin/penyewa/tambah'] = 'Manajemen_penyewa_controller/tambah';

// P9: Pembayaran
$route['pembayaran'] = 'Pembayaran_controller/index';
$route['pembayaran/detail'] = 'Pembayaran_controller/detail';
$route['pembayaran/upload'] = 'Pembayaran_controller/upload';
$route['pembayaran/bukti'] = 'Pembayaran_controller/bukti';
// P9: Verifikasi Pembayaran Admin
$route['admin/pembayaran'] = 'Verifikasi_pembayaran_controller/index';
$route['admin/pembayaran/verifikasi'] = 'Verifikasi_pembayaran_controller/verifikasi';
$route['admin/pembayaran/bukti'] = 'Verifikasi_pembayaran_controller/bukti';